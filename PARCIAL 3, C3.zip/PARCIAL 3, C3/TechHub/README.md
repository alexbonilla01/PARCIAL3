# TechHub

## Descripción
TechHub es una aplicación web desarrollada con Laravel y Vue.js. Este proyecto tiene como objetivo demostrar una estructura básica y funcional de una aplicación moderna utilizando estas tecnologías.

## Creado por
Ricardo Alexander Alvarenga Bonilla

## Tecnologías Utilizadas
- **Laravel**: 9.x
- **Vue.js**: 3.x
- **PHP**: 8.x
- **Composer**: 2.x
- **Node.js**: 14.x

## Requisitos Previos
Antes de comenzar, asegúrate de tener instaladas las siguientes herramientas:
- [Composer](https://getcomposer.org/)
- [Node.js](https://nodejs.org/)

## Instalación
Sigue los siguientes pasos para configurar el proyecto en tu entorno local.

### Clonar el Repositorio
```bash
git clone https://github.com/tu-usuario/techhub.git
cd techhub
