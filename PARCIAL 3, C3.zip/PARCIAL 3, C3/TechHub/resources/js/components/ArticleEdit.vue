<template>
    <div class="article-edit">
      <h2>Edit Article</h2>
      <form @submit.prevent="editArticle">
        <div>
          <label for="title">Title</label>
          <input type="text" v-model="title" id="title" required />
        </div>
        <div>
          <label for="body">Body</label>
          <textarea v-model="body" id="body" required></textarea>
        </div>
        <button type="submit">Save Changes</button>
      </form>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        title: 'Sample Article Title', // Replace with actual data
        body: 'Sample article body content.', // Replace with actual data
      };
    },
    methods: {
      editArticle() {
        // Simulate an API call
        console.log('Article updated:', {
          title: this.title,
          body: this.body,
        });
      },
    },
  };
  </script>
  
  <style scoped>
  .article-edit {
    max-width: 600px;
    margin: auto;
    padding: 20px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
  }
  .article-edit h2 {
    margin-bottom: 20px;
  }
  .article-edit form div {
    margin-bottom: 10px;
  }
  .article-edit label {
    display: block;
    margin-bottom: 5px;
  }
  .article-edit input, .article-edit textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
  }
  .article-edit button {
    background: #3498db;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }
  </style>
  