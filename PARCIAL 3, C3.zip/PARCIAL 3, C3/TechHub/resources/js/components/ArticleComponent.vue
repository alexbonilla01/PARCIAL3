﻿<template>
    <div class="article-component">
        <h2>{{ title }}</h2>
        <p>{{ content }}</p>
    </div>
</template>

<script>
export default {
    name: 'ArticleComponent',
    props: {
        title: {
            type: String,
            required: true
        },
        content: {
            type: String,
            required: true
        }
    }
}
</script>

<style scoped>
.article-component {
    background-color: #fff;
    border: 1px solid #ddd;
    padding: 20px;
    margin: 20px 0;
    border-radius: 5px;
}

.article-component h2 {
    margin-top: 0;
}

.article-component p {
    margin: 10px 0 0;
}
</style>
