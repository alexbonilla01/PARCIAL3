<template>
    <div class="article-list">
      <h2>Article List</h2>
      <ul>
        <li v-for="article in articles" :key="article.id">
          <h3>{{ article.title }}</h3>
          <p>{{ article.body }}</p>
        </li>
      </ul>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        articles: [
          { id: 1, title: 'First Article', body: 'This is the first article.' },
          { id: 2, title: 'Second Article', body: 'This is the second article.' },
          // Add more articles here
        ],
      };
    },
  };
  </script>
  
  <style scoped>
  .article-list {
    max-width: 800px;
    margin: auto;
    padding: 20px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
  }
  .article-list h2 {
    margin-bottom: 20px;
  }
  .article-list ul {
    list-style: none;
    padding: 0;
  }
  .article-list li {
    margin-bottom: 20px;
  }
  .article-list h3 {
    margin-bottom: 10px;
  }
  .article-list p {
    margin: 0;
  }
  </style>
  