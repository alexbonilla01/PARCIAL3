﻿<template>
    <div class="example-component">
        <h2>Example Component</h2>
        <p>This is an example component for the TechHub project.</p>
    </div>
</template>

<script>
export default {
    name: 'ExampleComponent'
}
</script>

<style scoped>
.example-component {
    background-color: #f9f9f9;
    border: 1px solid #ddd;
    padding: 20px;
    margin: 20px 0;
    border-radius: 5px;
}
</style>
