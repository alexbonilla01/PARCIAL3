﻿<template>
    <header class="header-component">
        <h1>{{ title }}</h1>
        <p>{{ subtitle }}</p>
    </header>
</template>

<script>
export default {
    name: 'HeaderComponent',
    props: {
        title: {
            type: String,
            required: true
        },
        subtitle: {
            type: String,
            required: true
        }
    }
}
</script>

<style scoped>
.header-component {
    background-color: #3498db;
    color: #fff;
    text-align: center;
    padding: 20px 0;
}

.header-component h1 {
    margin: 0;
    font-size: 2.5em;
}

.header-component p {
    margin: 5px 0 0;
    font-size: 1.2em;
}
</style>
