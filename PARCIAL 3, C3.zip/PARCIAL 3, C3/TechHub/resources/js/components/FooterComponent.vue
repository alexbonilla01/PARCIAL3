﻿<template>
    <footer class="footer-component">
        <p>&copy; 2024 TechHub. All rights reserved.</p>
    </footer>
</template>

<script>
export default {
    name: 'FooterComponent'
}
</script>

<style scoped>
.footer-component {
    background-color: #333;
    color: #fff;
    text-align: center;
    padding: 20px 0;
    position: fixed;
    width: 100%;
    bottom: 0;
}
</style>
