<template>
    <div class="article-create">
      <h2>Create Article</h2>
      <form @submit.prevent="createArticle">
        <div>
          <label for="title">Title</label>
          <input type="text" v-model="title" id="title" required />
        </div>
        <div>
          <label for="body">Body</label>
          <textarea v-model="body" id="body" required></textarea>
        </div>
        <button type="submit">Create</button>
      </form>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        title: '',
        body: '',
      };
    },
    methods: {
      createArticle() {
        // Simulate an API call
        console.log('Article created:', {
          title: this.title,
          body: this.body,
        });
        this.title = '';
        this.body = '';
      },
    },
  };
  </script>
  
  <style scoped>
  .article-create {
    max-width: 600px;
    margin: auto;
    padding: 20px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
  }
  .article-create h2 {
    margin-bottom: 20px;
  }
  .article-create form div {
    margin-bottom: 10px;
  }
  .article-create label {
    display: block;
    margin-bottom: 5px;
  }
  .article-create input, .article-create textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
  }
  .article-create button {
    background: #3498db;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }
  </style>
  