﻿<?php

return [
    'welcome' => 'Bienvenido a TechHub',
    'created_by' => 'Creado por Ricardo Alexander Alvarenga Bonilla',
    'article' => [
        'create' => 'Crear Artículo',
        'edit' => 'Editar Artículo',
        'list' => 'Lista de Artículos',
    ],
    'form' => [
        'title' => 'Título',
        'body' => 'Cuerpo',
        'submit' => 'Enviar',
    ],
];
