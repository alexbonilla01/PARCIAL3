﻿<?php

return [
    'welcome' => 'Welcome to TechHub',
    'created_by' => 'Created by Ricardo Alexander Alvarenga Bonilla',
    'article' => [
        'create' => 'Create Article',
        'edit' => 'Edit Article',
        'list' => 'Article List',
    ],
    'form' => [
        'title' => 'Title',
        'body' => 'Body',
        'submit' => 'Submit',
    ],
];
