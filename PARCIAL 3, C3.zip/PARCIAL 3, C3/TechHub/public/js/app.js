﻿document.addEventListener('DOMContentLoaded', function() {
    const button = document.getElementById('myButton');
    button.addEventListener('click', function() {
        alert('Button was clicked!');
    });

    function toggleVisibility(elementId) {
        const element = document.getElementById(elementId);
        if (element.style.display === 'none') {
            element.style.display = 'block';
        } else {
            element.style.display = 'none';
        }
    }

    const toggleButton = document.getElementById('toggleButton');
    toggleButton.addEventListener('click', function() {
        toggleVisibility('toggleElement');
    });

    function fetchData() {
        fetch('https://jsonplaceholder.typicode.com/posts')
            .then(response => response.json())
            .then(data => {
                const container = document.getElementById('dataContainer');
                container.innerHTML = '';
                data.forEach(post => {
                    const div = document.createElement('div');
                    div.className = 'post';
                    div.innerHTML = `<h3>${post.title}</h3><p>${post.body}</p>`;
                    container.appendChild(div);
                });
            })
            .catch(error => console.error('Error fetching data:', error));
    }

    const fetchButton = document.getElementById('fetchButton');
    fetchButton.addEventListener('click', fetchData);

    const form = document.getElementById('myForm');
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        if (name === '' || email === '') {
            alert('Please fill out all fields.');
        } else {
            alert('Form submitted successfully.');
        }
    });

    const animateButton = document.getElementById('animateButton');
    animateButton.addEventListener('click', function() {
        const box = document.getElementById('box');
        let position = 0;
        const interval = setInterval(frame, 10);
        function frame() {
            if (position == 350) {
                clearInterval(interval);
            } else {
                position++;
                box.style.top = position + 'px';
                box.style.left = position + 'px';
            }
        }
    });

    const saveButton = document.getElementById('saveButton');
    saveButton.addEventListener('click', function() {
        const input = document.getElementById('localStorageInput').value;
        localStorage.setItem('savedData', input);
        alert('Data saved to local storage.');
    });

    const loadButton = document.getElementById('loadButton');
    loadButton.addEventListener('click', function() {
        const savedData = localStorage.getItem('savedData');
        alert('Loaded data from local storage: ' + savedData);
    });

    const countdownButton = document.getElementById('countdownButton');
    countdownButton.addEventListener('click', function() {
        let timeLeft = 10;
        const countdownDisplay = document.getElementById('countdownDisplay');
        const interval = setInterval(function() {
            if (timeLeft <= 0) {
                clearInterval(interval);
                countdownDisplay.innerHTML = 'Time\'s up!';
            } else {
                countdownDisplay.innerHTML = timeLeft + ' seconds remaining';
                timeLeft--;
            }
        }, 1000);
    });
});
